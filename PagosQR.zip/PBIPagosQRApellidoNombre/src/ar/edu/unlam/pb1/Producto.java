package ar.edu.unlam.pb1;

public class Producto {
	
	/***
	 * Constructor de la clase
	 * @param codigo
	 * @param precio
	 * @param descripcion
	 */
	public Producto(int codigo, double precio, String descripcion) {
		
	}
	
	/****
	 * Devuelve el c�digo de un producto
	 * @return Devuelve el c�digo de un producto 
	 */
	public int getCodigo() {
		return 0;
	}
	
	/****
	 * Devuelve el precio de un producto
	 * @return Devuelve el precio de un producto 
	 */
	public double getPrecio() {
		return 0.00;
	}
	
	/****
	 * Establece el precio de un producto
	 * @param precio - Precio del producto 
	 */
	public void setPrecio(double precio) {
		
	}

	/****
	 * Devuelve la descripci�n de un producto
	 * @return Devuelve la descripci�n de un producto 
	 */
	public String getDescripcion() {
		return "";
	}
	
	/****
	 * Establece la descripcion de un producto
	 * @param descripcion - Descripci�n del producto
	 */
	public void setDescripcion(String descripcion) {
		
	}
	
	/****
	 * Devuelve informaci�n descripctiva del producto 
	 * @return String que describa el estado del objeto
	 */
	public String toString() {
		return "";
	}
}
